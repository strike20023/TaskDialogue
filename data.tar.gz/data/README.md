# TaskDialogue 数据目录

## 目录结构

```
data/
├── db/
│   ├── multiwoz.db       # MultiWOZ 主数据库（餐厅、酒店、景点、火车等信息）
│   └── multiwoz_book.db  # MultiWOZ 预订数据库（用于记录预订操作）
├── multiwoz/
│   ├── data.json         # 完整的 MultiWOZ 2.4 对话数据（264M）
│   ├── testListFile.json # 测试集对话 ID 列表
│   ├── valListFile.json  # 验证集对话 ID 列表
│   ├── ontology.json     # 数据集本体（槽位和值的定义）
│   └── dialogue_acts.json # 对话行为标注
└── README.md
```

## 数据说明

### 1. 数据库文件（db/）

- **`multiwoz.db`**: 包含 MultiWOZ 数据集的所有实体信息
  - 餐厅（restaurant）
  - 酒店（hotel）
  - 景点（attraction）
  - 火车（train）
  - 出租车（taxi）等

- **`multiwoz_book.db`**: 用于存储对话中的预订记录
  - 餐厅预订
  - 酒店预订
  - 火车预订
  - 出租车预订

### 2. MultiWOZ 对话数据集（multiwoz/）

所有对话数据已包含在项目中，无需额外下载。

- **`data.json`**: 完整的 MultiWOZ 2.4 对话数据
  - 包含所有对话（train + validation + test）
  - 大小：264MB
  - 格式：`{dialogue_id: {goal: {...}, log: [...]}}`

- **`testListFile.json`**: 测试集对话 ID 列表
- **`valListFile.json`**: 验证集对话 ID 列表
- **`ontology.json`**: 槽位和值的定义
- **`dialogue_acts.json`**: 对话行为标注

### 3. 数据集分割

项目会自动根据 split 文件划分数据集：

- **train**: 所有不在 test 和 validation 列表中的对话
- **test**: testListFile.json 中列出的对话
- **valid**: valListFile.json 中列出的对话

## 配置使用

所有配置文件已更新为使用项目内的数据：

```yaml
data:
  # 主数据文件路径（相对于项目根目录）
  data_path: "data/multiwoz/data.json"
  
  # 数据集 split: train, test, valid
  split: test
  
  # 数据集名称
  dataset_name: multiwoz24
  
  # 是否移除 police 和 hospital 领域
  remove_police_hospital: true
```

### 使用不同的数据分割

在配置文件或命令行中指定：

```bash
# 使用测试集
./run_inference.sh --split test

# 使用训练集
./run_inference.sh --split train

# 使用验证集
./run_inference.sh --split valid
```

## 数据统计

- **总对话数**: 约 10,000+ 对话
- **领域**: restaurant, hotel, attraction, train, taxi
- **平均对话轮数**: 约 13 轮
- **数据集版本**: MultiWOZ 2.4

## 评估指标

项目支持以下评估指标：

- **inform**: 是否提供了所需信息
- **success**: 对话是否成功完成任务
- **book**: 预订是否成功
- **jga**: Joint Goal Accuracy（联合目标准确率）
- **f1**: F1 分数

## 数据处理

### 移除特定领域

配置中可以选择移除 police 和 hospital 领域的对话：

```yaml
data:
  remove_police_hospital: true
```

### 限制推理样本数

在推理配置中可以限制处理的对话数量：

```yaml
inference:
  num_samples: 50  # 只处理 50 个对话
  # num_samples: null  # 处理所有对话
```

## 数据来源

数据来自 MultiWOZ 2.4 数据集：
- 论文: https://arxiv.org/abs/2010.05594
- GitHub: https://github.com/smartyfh/MultiWOZ2.4
